package com.sahaj.hotel.processor.impl;

import com.sahaj.hotel.bean.Consumption;
import com.sahaj.hotel.bean.Floor;
import com.sahaj.hotel.bean.Light;
import com.sahaj.hotel.bean.SubCorridor;
import com.sahaj.hotel.bean.output.ProcessorResult;
import com.sahaj.hotel.constant.DeviceStatus;
import com.sahaj.hotel.event.DelayEventProcessing;
import com.sahaj.hotel.processor.CorridorProcessor;
import com.sahaj.hotel.util.HotelUtil;

import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class SubCorridorProcessor implements CorridorProcessor<SubCorridor> {


    @Override
    public ProcessorResult process(SubCorridor input, Floor floor) {
        ProcessorResult result = new ProcessorResult();
        Integer totalUnit = 0;
        processingLight(input, floor);
        processingAirCondition(input, floor);
        result.setProcessorConsumption(new Consumption(totalUnit));
        return result;
    }

    public void processingLight(SubCorridor input, Floor floor) {

        if (!HotelUtil.isTimeBetweenSixPMtoSixAM()) {
            input.getLight().setDeviceStatus(DeviceStatus.OFF);
            floor.getTotalconsumption().remove(input.getLight().getConsumption().getUnit());
        } else if (HotelUtil.isLastProcessTimeisMoreThanLimit(input.getLastProcessedTime())) {
            input.setLastProcessedTime(Instant.now().toEpochMilli());
            if(input.getLight().equals(DeviceStatus.OFF)){
                floor.getTotalconsumption().add(input.getLight().getConsumption().getUnit());
            }
            input.getLight().setDeviceStatus(DeviceStatus.ON);
            System.out.println("Adding Subcorridor to Delay processing with corridor number : "+input.getSubCorridorNumber());
            DelayEventProcessing.taskScheduleSubCorridor(input,floor);

        } else {
            if(input.getLight().equals(DeviceStatus.ON)){
                floor.getTotalconsumption().remove(input.getLight().getConsumption().getUnit());
            }
            input.getLight().setDeviceStatus(DeviceStatus.OFF);
        }

    }

    public void processingAirCondition(SubCorridor input, Floor floor) {
        Integer currentAcConsump = input.getAirCondition().getConsumption().getUnit();
        if ((floor.getTotalconsumption().getUnit() + currentAcConsump) > HotelUtil.calculateFloorConsumptionLimit(floor)) {
            System.out.println("Cross the Limit of consumption in hotel so trying to switch off the other AC ");
            if(input.getAirCondition().equals(DeviceStatus.OFF)){
                floor.getTotalconsumption().add(input.getAirCondition().getConsumption().getUnit());
            }
            input.getAirCondition().setDeviceStatus(DeviceStatus.ON);
            processPreviousSubCorridor(input, floor);
        } else {
            if(input.getAirCondition().equals(DeviceStatus.OFF)){
                floor.getTotalconsumption().add(input.getAirCondition().getConsumption().getUnit());
            }
            input.getAirCondition().setDeviceStatus(DeviceStatus.ON);
        }

    }

    private void processPreviousSubCorridor(SubCorridor input, Floor floor) {
        Optional<SubCorridor> subCorridor = floor.getSubCorridors().stream().filter(e -> {
            return !e.getSubCorridorNumber().equals(input.getSubCorridorNumber());
        }).filter(e -> {
            return !HotelUtil.isLastProcessTimeisMoreThanLimit(e.getLastProcessedTime());
        }).sorted().findFirst();
        if (subCorridor.isPresent()) {
            subCorridor.get().getAirCondition().setDeviceStatus(DeviceStatus.OFF);
            floor.getTotalconsumption().remove(subCorridor.get().getAirCondition().getConsumption().getUnit());
        }
    }
}

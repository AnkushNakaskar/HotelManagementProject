package com.sahaj.hotel.processor;

import com.sahaj.hotel.bean.AirCondition;
import com.sahaj.hotel.bean.Floor;
import com.sahaj.hotel.bean.Light;
import com.sahaj.hotel.bean.SubCorridor;
import com.sahaj.hotel.bean.output.ProcessorResult;

public interface CorridorProcessor<T> {

    public ProcessorResult process(T input, Floor floor);

    public void processingLight(T input, Floor floor);

    public void processingAirCondition(T input, Floor floor);
}

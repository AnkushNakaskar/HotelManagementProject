package com.sahaj.hotel.bean.output;

import com.sahaj.hotel.bean.Consumption;
import lombok.Data;

import java.util.List;

@Data
public class ProcessorResult {

    private Consumption processorConsumption;

}

package com.sahaj.hotel.bean;

import com.sahaj.hotel.processor.CorridorProcessor;
import lombok.Data;

@Data
public class SubCorridor implements  Comparable<SubCorridor>{

    private Light light;

    private AirCondition airCondition;

    private Long lastProcessedTime;

    private Integer subCorridorNumber;

    private CorridorProcessor<SubCorridor> processor;

    public SubCorridor(CorridorProcessor<SubCorridor> processor){
        this.processor=processor;
    }


    @Override
    public int compareTo(SubCorridor o) {
        return this.getSubCorridorNumber().compareTo(o.getSubCorridorNumber());
    }

    public void processLight(Floor floor){
        processor.processingLight(this,floor);
    }

    public void processAirCondition(Floor floor){
        processor.processingAirCondition(this,floor);
    }
}

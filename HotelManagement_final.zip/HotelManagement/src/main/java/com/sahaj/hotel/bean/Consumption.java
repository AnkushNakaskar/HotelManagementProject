package com.sahaj.hotel.bean;

import com.sahaj.hotel.constant.DeviceStatus;
import lombok.Data;

@Data
public class Consumption {

    private Integer unit;

    public Consumption(Integer unit){
        this.unit=unit;
    }

    public boolean add(Integer unit){
        this.unit+=unit;
        return true;
    }
    public boolean remove(Integer unit){
        this.unit-=unit;
        return true;

    }

}

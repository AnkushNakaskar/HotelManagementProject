package com.sahaj.hotel.bean;

import com.sahaj.hotel.processor.CorridorProcessor;
import lombok.Data;

@Data
public class Corridor {

    private Light light;

    private AirCondition airCondition;

    private Long lastProcessedTime;

    private Integer corridorNumber;

    private CorridorProcessor<Corridor> processor;


    public Corridor(CorridorProcessor<Corridor> processor){
        this.processor=processor;
    }

    public void processLight(Floor floor){
        processor.processingLight(this,floor);
    }

    public void processAirCondition(Floor floor){
        processor.processingAirCondition(this,floor);
    }

}

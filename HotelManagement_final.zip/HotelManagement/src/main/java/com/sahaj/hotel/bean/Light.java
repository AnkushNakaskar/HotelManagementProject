package com.sahaj.hotel.bean;

import com.sahaj.hotel.constant.DeviceStatus;
import lombok.Data;

@Data
public class Light {

    private Consumption consumption;
    private DeviceStatus deviceStatus;

    public Light(){
        consumption =new Consumption(5);
        deviceStatus =DeviceStatus.ON;
    }

}

package com.sahaj.hotel.manager.impl;

import com.sahaj.hotel.bean.Floor;
import com.sahaj.hotel.bean.Hotel;
import com.sahaj.hotel.manager.HotelManager;
import com.sahaj.hotel.processor.Processor;
import lombok.Data;

import java.util.List;


@Data
public class HotelManagerImpl implements HotelManager {

    @Override
    public void manage(Hotel hotel) {
        System.out.println("Processing hotel lighting system : "+hotel);
        List<Floor> floors = hotel.getFloors();
        if(floors!=null && !floors.isEmpty()){
         floors.stream().forEach(e->{
             e.process();
         });
        }

    }
}

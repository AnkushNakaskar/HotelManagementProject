package com.sahaj.hotel.processor;

import com.sahaj.hotel.bean.output.ProcessorResult;

public interface Processor<T> {

    public ProcessorResult process(T input);
}

package com.sahaj.hotel.bean;

import lombok.Data;

import java.util.List;

@Data
public class Hotel {

    private List<Floor> floors;
}

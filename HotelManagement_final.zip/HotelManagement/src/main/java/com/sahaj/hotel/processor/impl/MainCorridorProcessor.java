package com.sahaj.hotel.processor.impl;

import com.sahaj.hotel.bean.Consumption;
import com.sahaj.hotel.bean.Corridor;
import com.sahaj.hotel.bean.Floor;
import com.sahaj.hotel.bean.output.ProcessorResult;
import com.sahaj.hotel.constant.DeviceStatus;
import com.sahaj.hotel.event.DelayEventProcessing;
import com.sahaj.hotel.processor.CorridorProcessor;
import com.sahaj.hotel.util.HotelUtil;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class MainCorridorProcessor implements CorridorProcessor<Corridor> {



    /*
    Main Corridor does not have any restriction on Light timing and AC status ,Both will be always ON
     */
    @Override
    public ProcessorResult process(Corridor input, Floor floor) {

        ProcessorResult result = new ProcessorResult();
        result.setProcessorConsumption(new Consumption(15));

        return result;
    }

    @Override
    public void processingLight(Corridor input, Floor floor) {
        if (!HotelUtil.isTimeBetweenSixPMtoSixAM()) {
            input.getLight().setDeviceStatus(DeviceStatus.OFF);
        }else if(HotelUtil.isLastProcessTimeisMoreThanLimit(input.getLastProcessedTime())){
            input.getLight().setDeviceStatus(DeviceStatus.ON);
            floor.getTotalconsumption().add(input.getLight().getConsumption().getUnit());
            input.setLastProcessedTime(Instant.now().toEpochMilli());
            System.out.println("Adding Main corridor to Delay processing with corridor number : "+input.getCorridorNumber());
            DelayEventProcessing.taskScheduleCorridor(input,floor);
        }
        else {
            input.getLight().setDeviceStatus(DeviceStatus.OFF);
        }
    }

    @Override
    public void processingAirCondition(Corridor input, Floor floor) {
        input.getAirCondition().setDeviceStatus(DeviceStatus.ON);
        floor.getTotalconsumption().add(input.getAirCondition().getConsumption().getUnit());
    }
}

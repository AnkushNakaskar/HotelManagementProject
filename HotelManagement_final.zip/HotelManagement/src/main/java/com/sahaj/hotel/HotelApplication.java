package com.sahaj.hotel;

import com.sahaj.hotel.bean.*;
import com.sahaj.hotel.event.DelayEventProcessing;
import com.sahaj.hotel.manager.HotelManager;
import com.sahaj.hotel.manager.impl.HotelManagerImpl;
import com.sahaj.hotel.processor.CorridorProcessor;
import com.sahaj.hotel.processor.Processor;
import com.sahaj.hotel.processor.impl.FloorProcessor;
import com.sahaj.hotel.processor.impl.MainCorridorProcessor;
import com.sahaj.hotel.processor.impl.SubCorridorProcessor;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class HotelApplication {

    public static void main(String[] args) {


        HotelManager hotelManager = new HotelManagerImpl();
        Hotel hotel = new Hotel();

        List<Floor> floors = new LinkedList<>();
        Floor floorOne = populateFloor();
        Floor floorTwo = populateFloor();
        floors.add(floorOne);
        hotel.setFloors(floors);
        System.out.println("-------Ankush------");
        System.out.println(Instant.now());
        System.out.println("-------Ankush------");
        hotelManager.manage(hotel);
//        DelayEventProcessing.taskScheduleCorridor(floorOne.getMainCorridors().get(0),floorOne);
//        Runnable taskSchedule = () -> {
//            System.out.println("Ankush");
//            System.out.println(Instant.now());
//        };
//        ScheduledExecutorService ses = Executors.newScheduledThreadPool(10);
//        ses.schedule(taskSchedule, 2, TimeUnit.SECONDS);



    }

    public static Floor populateFloor(){

        CorridorProcessor<SubCorridor> subCorridorProcessor = new SubCorridorProcessor();
        CorridorProcessor<Corridor> corridorProcessor = new MainCorridorProcessor();
        Processor<Floor> floorProcessor = new FloorProcessor();


        List<Corridor> mainCorridors = new LinkedList<>();
        Corridor corridor =new Corridor(corridorProcessor);
        AirCondition floorOneCorridorAc =new AirCondition();
        Light floorOneCorridorLight=new Light();
        corridor.setAirCondition(floorOneCorridorAc);
        corridor.setLight(floorOneCorridorLight);
        corridor.setCorridorNumber(1);
        corridor.setLastProcessedTime(Instant.now().toEpochMilli());
        mainCorridors.add(corridor);

        List<SubCorridor> subCorridors = new LinkedList<>();

        SubCorridor subCorridorOne =new SubCorridor(subCorridorProcessor);
        AirCondition floorOneSubCorridorOneAc =new AirCondition();
        Light floorOneSubCorridorOneLight=new Light();
        subCorridorOne.setAirCondition(floorOneSubCorridorOneAc);
        subCorridorOne.setLight(floorOneSubCorridorOneLight);
        subCorridorOne.setSubCorridorNumber(1);
        subCorridorOne.setLastProcessedTime(Instant.now().toEpochMilli());
//        subCorridorOne.setLastProcessedTime(1551537353691L);

        SubCorridor subCorridorTwo =new SubCorridor(subCorridorProcessor);
        AirCondition floorOneSubCorridorTwoAc =new AirCondition();
        Light floorOneSubCorridorTwoLight=new Light();
        subCorridorTwo.setAirCondition(floorOneSubCorridorTwoAc);
        subCorridorTwo.setLight(floorOneSubCorridorTwoLight);
        subCorridorTwo.setSubCorridorNumber(2);
        subCorridorTwo.setLastProcessedTime(Instant.now().toEpochMilli());
//        subCorridorTwo.setLastProcessedTime(1551537353691L);

        subCorridors.add(subCorridorOne);
        subCorridors.add(subCorridorTwo);

        return new Floor(mainCorridors, subCorridors,floorProcessor);

    }
}

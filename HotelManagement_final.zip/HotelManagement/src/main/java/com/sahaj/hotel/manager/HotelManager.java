package com.sahaj.hotel.manager;

import com.sahaj.hotel.bean.Hotel;

public interface HotelManager {

    public void manage(Hotel hotel);
}

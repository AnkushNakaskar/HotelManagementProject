package com.sahaj.hotel.event;

import com.sahaj.hotel.bean.Corridor;
import com.sahaj.hotel.bean.Floor;
import com.sahaj.hotel.bean.SubCorridor;
import com.sahaj.hotel.util.HotelUtil;

import java.time.Instant;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class DelayEventProcessing {

    private static ScheduledExecutorService ses = Executors.newScheduledThreadPool(10);
    private static Integer noMovementCheckTime=1;

    public static  void taskScheduleSubCorridor(SubCorridor subCorridor, Floor floor) {
        Runnable taskSchedule = () -> {

            if (!HotelUtil.isLastProcessTimeisMoreThanLimit(subCorridor.getLastProcessedTime())){
                System.out.println("Processing Subcorridor to Delay processing with corridor number : "+subCorridor.getSubCorridorNumber());
                floor.getTotalconsumption().remove(subCorridor.getLight().getConsumption().getUnit());
                subCorridor.processLight(floor);
                subCorridor.processAirCondition(floor);
                subCorridor.setLastProcessedTime(Instant.now().toEpochMilli());
                floor.printResult();
                System.out.println(Instant.now());
                System.out.println("Processing Subcorridor end  to Delay processing with corridor number : "+subCorridor.getSubCorridorNumber());
            }


        };
        ses.schedule(taskSchedule, noMovementCheckTime, TimeUnit.MINUTES);
//        try {
////            ses.awaitTermination(4,TimeUnit.MINUTES);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
    }

    public static void taskScheduleCorridor(Corridor corridor, Floor floor)  {
        Runnable taskSchedule = () -> {

            if (!HotelUtil.isLastProcessTimeisMoreThanLimit(corridor.getLastProcessedTime())){
                System.out.println("Processing Corridor start to Delay processing with corridor number : "+corridor.getCorridorNumber());                corridor.processLight(floor);
                corridor.processAirCondition(floor);
                corridor.processLight(floor);
                floor.getTotalconsumption().remove(corridor.getLight().getConsumption().getUnit());
                corridor.setLastProcessedTime(Instant.now().toEpochMilli());
                floor.printResult();
                System.out.println(Instant.now());
                System.out.println("Processing Corridor end to Delay processing with corridor number : "+corridor.getCorridorNumber());            }


        };
        ses.schedule(taskSchedule, noMovementCheckTime, TimeUnit.MINUTES);
//        try {
////            ses.awaitTermination(4,TimeUnit.SECONDS);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
    }
}

package com.sahaj.hotel.util;

import com.sahaj.hotel.bean.Floor;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class HotelUtil {

    private static final Integer startLightTime = 18;//These configuration should be from external properties file

    private static final Integer stopLightTime = 6;

    private static final Integer allowMotionLimit = 1;



    private static LocalDateTime sixPmTime = LocalDate.now().atTime(startLightTime, 00, 00);
    private static LocalDateTime sixAmTime = LocalDate.now().plusDays(1).atTime(stopLightTime, 00, 00);
    private static LocalDateTime now = LocalDateTime.now();
    public static Integer calculateFloorConsumptionLimit(Floor floor){
        return floor.getMainCorridors().size()*15 +floor.getSubCorridors().size()*10;
    }

    public static boolean isTimeBetweenSixPMtoSixAM(){
        if(now.isAfter(sixPmTime) && now.isBefore(sixAmTime)){
            return true;
        }
        return false;
    }

    public static boolean isLastProcessTimeisMoreThanLimit(Long inputTime){
        LocalDateTime lastProcessedTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(inputTime), ZoneId.systemDefault()).plusMinutes(allowMotionLimit);
        LocalDateTime now = LocalDateTime.now();
        if(now.isBefore(lastProcessedTime)){
            return true;
        }
        return  false;
    }
}

package com.sahaj.hotel.bean;

import com.sahaj.hotel.processor.Processor;
import lombok.Data;

import java.util.List;

@Data
public class Floor {

    private List<Corridor> mainCorridors;

    private List<SubCorridor> subCorridors;

    private Consumption totalconsumption;

    private Processor<Floor> processor;



    public void process(){
        processor.process(this);
    }
    public Floor(List<Corridor> mainCorridors,List<SubCorridor> subCorridors,Processor<Floor> processor){
        this.mainCorridors=mainCorridors;
        this.subCorridors=subCorridors;
        totalconsumption=new Consumption(0);
        this.processor=processor;
    }

    public synchronized void  printResult() {

        System.out.println("\n\n\n----------------------------------------------------------------------------------------");
        if (this.getMainCorridors() != null && !this.getMainCorridors().isEmpty()) {
            this.getMainCorridors().stream().forEach(e -> {
                System.out.println("Main corridor  " + e.getCorridorNumber() + " :: " + " Light : " + " " + e.getLight().getDeviceStatus() + " AC : " + e.getAirCondition().getDeviceStatus());
            });
        }
        if (this.getSubCorridors() != null && !this.getSubCorridors().isEmpty()) {
            this.getSubCorridors().stream().forEach(e -> {
                System.out.println("Sub corridor   " + e.getSubCorridorNumber() + " :: " + " Light :  " + e.getLight().getDeviceStatus() + " AC : " + e.getAirCondition().getDeviceStatus());
            });
        }
        System.out.println("----------------------------------------------------------------------------------------\n\n\n");
    }

}

package com.sahaj.hotel.constant;

public enum DeviceStatus {

    ON,OFF;
}

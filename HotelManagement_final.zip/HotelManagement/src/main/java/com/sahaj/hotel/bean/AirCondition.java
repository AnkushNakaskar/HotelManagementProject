package com.sahaj.hotel.bean;

import com.sahaj.hotel.constant.DeviceStatus;
import lombok.Data;

@Data
public class AirCondition {

    private Consumption consumption ;
    private DeviceStatus deviceStatus;

    public AirCondition(){
        consumption =new Consumption(10);
        deviceStatus =DeviceStatus.ON;
    }
}

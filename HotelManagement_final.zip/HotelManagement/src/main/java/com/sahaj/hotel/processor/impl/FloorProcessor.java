package com.sahaj.hotel.processor.impl;

import com.sahaj.hotel.bean.Consumption;
import com.sahaj.hotel.bean.Floor;
import com.sahaj.hotel.bean.output.ProcessorResult;
import com.sahaj.hotel.processor.Processor;

import java.util.Objects;

public class FloorProcessor implements Processor<Floor> {


    @Override
    public ProcessorResult process(Floor input) {
        if (input.getMainCorridors() != null && (!input.getMainCorridors().isEmpty())) {
            input.getMainCorridors().stream().filter(Objects::nonNull).forEach(e -> {
                e.processLight(input);
                e.processAirCondition(input);
            });
        }
        if (input.getSubCorridors() != null && (!input.getSubCorridors().isEmpty())) {
            input.getSubCorridors().stream().filter(Objects::nonNull).forEach(e -> {
                e.processLight(input);
                e.processAirCondition(input);
            });
        }
        ProcessorResult processorResult = new ProcessorResult();
        processorResult.setProcessorConsumption(new Consumption(input.getTotalconsumption().getUnit()));
        input.printResult();
        return processorResult;
    }


}

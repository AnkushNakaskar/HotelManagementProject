package com.sahaj.hotel.processor.impl;

import com.sahaj.hotel.HotelApplicationTestUtil;
import com.sahaj.hotel.bean.Corridor;
import com.sahaj.hotel.bean.Floor;
import com.sahaj.hotel.constant.DeviceStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class MainCorridorProcessorTest {

    @InjectMocks
    private MainCorridorProcessor mainCorridorProcessor;

    @Before
    public void setup(){
        MockitoAnnotations.initMocks(this);
        mainCorridorProcessor =new MainCorridorProcessor();
    }

    @Test
    public void testLight(){
        Floor floor=HotelApplicationTestUtil.populateFloor();
        Corridor corridor = floor.getMainCorridors().get(0);
        mainCorridorProcessor.processingLight(corridor,floor);
        mainCorridorProcessor.processingAirCondition(corridor,floor);

        LocalDateTime sixPmTime = LocalDate.now().atTime(18, 00, 00);
        LocalDateTime sixAmTime = LocalDate.now().atTime(6, 00, 00);
        LocalDateTime now = LocalDateTime.now();
        Assert.assertEquals(DeviceStatus.ON,corridor.getAirCondition().getDeviceStatus());
        if (now.isAfter(sixPmTime) && now.isBefore(sixAmTime)) {
            Assert.assertEquals(DeviceStatus.ON,corridor.getLight().getDeviceStatus());
        }else{
            Assert.assertEquals(DeviceStatus.OFF,corridor.getLight().getDeviceStatus());
        }


    }
}

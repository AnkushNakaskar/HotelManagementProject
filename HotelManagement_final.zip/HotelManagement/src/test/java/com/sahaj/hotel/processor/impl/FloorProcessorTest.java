package com.sahaj.hotel.processor.impl;

import com.sahaj.hotel.HotelApplicationTestUtil;
import com.sahaj.hotel.bean.*;
import com.sahaj.hotel.processor.CorridorProcessor;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.LinkedList;
import java.util.List;

public class FloorProcessorTest {

    @InjectMocks
    private FloorProcessor floorProcessor;

    @Mock
    private CorridorProcessor<SubCorridor> subCorridorProcessor;

    @Mock
    private CorridorProcessor<Corridor> mainCorridorProcessor;

    @Before
    public void setup(){
        MockitoAnnotations.initMocks(this);
        floorProcessor =new FloorProcessor();
    }

    @Test
    public void testNoCorridors(){
        Floor input = Mockito.mock(Floor.class);
        Mockito.when(input.getTotalconsumption()).thenReturn(new Consumption(5));
        floorProcessor.process(input);
        Mockito.verify(subCorridorProcessor,Mockito.times(0)).process(Mockito.any(),Mockito.any());
        Mockito.verify(mainCorridorProcessor,Mockito.times(0)).process(Mockito.any(),Mockito.any());
    }

    @Test
    public void testProcessMainCorridor(){
        Floor floor=HotelApplicationTestUtil.populateFloor();
        floor.setSubCorridors(null);
        floor.getMainCorridors().get(0).setProcessor(mainCorridorProcessor);
        floorProcessor.process(floor);
        Mockito.verify(subCorridorProcessor,Mockito.times(0)).process(Mockito.any(),Mockito.any());
        Mockito.verify(mainCorridorProcessor,Mockito.times(1)).processingAirCondition(Mockito.any(),Mockito.any());
        Mockito.verify(mainCorridorProcessor,Mockito.times(1)).processingLight(Mockito.any(),Mockito.any());
    }

    @Test
    public void testProcessCorridors(){
        Floor floor= HotelApplicationTestUtil.populateFloor();
        floor.getMainCorridors().get(0).setProcessor(mainCorridorProcessor);
        floor.getSubCorridors().get(0).setProcessor(subCorridorProcessor);
        floor.getSubCorridors().get(1).setProcessor(subCorridorProcessor);
        floorProcessor.process(floor);

        Mockito.verify(subCorridorProcessor,Mockito.times(2)).processingLight(Mockito.any(),Mockito.any());
        Mockito.verify(mainCorridorProcessor,Mockito.times(1)).processingLight(Mockito.any(),Mockito.any());
    }



}

package com.sahaj.hotel;

import com.sahaj.hotel.bean.*;
import com.sahaj.hotel.processor.CorridorProcessor;
import com.sahaj.hotel.processor.Processor;
import com.sahaj.hotel.processor.impl.FloorProcessor;
import com.sahaj.hotel.processor.impl.MainCorridorProcessor;
import com.sahaj.hotel.processor.impl.SubCorridorProcessor;

import java.util.LinkedList;
import java.util.List;

public class HotelApplicationTestUtil {

    public static Floor populateFloor(){

        CorridorProcessor<SubCorridor> subCorridorProcessor = new SubCorridorProcessor();
        CorridorProcessor<Corridor> corridorProcessor = new MainCorridorProcessor();
        Processor<Floor> floorProcessor = new FloorProcessor();
        List<Corridor> mainCorridors = new LinkedList<>();
        Corridor corridor =new Corridor(corridorProcessor);
        AirCondition floorOneCorridorAc =new AirCondition();
        Light floorOneCorridorLight=new Light();
        corridor.setAirCondition(floorOneCorridorAc);
        corridor.setLight(floorOneCorridorLight);
        corridor.setCorridorNumber(1);
        mainCorridors.add(corridor);

        List<SubCorridor> subCorridors = new LinkedList<>();

        SubCorridor subCorridorOne =new SubCorridor(subCorridorProcessor);
        AirCondition floorOneSubCorridorOneAc =new AirCondition();
        Light floorOneSubCorridorOneLight=new Light();
        subCorridorOne.setAirCondition(floorOneSubCorridorOneAc);
        subCorridorOne.setLight(floorOneSubCorridorOneLight);
        subCorridorOne.setSubCorridorNumber(1);
//        subCorridorOne.setLastProcessedTime(Instant.now().toEpochMilli());
        subCorridorOne.setLastProcessedTime(1551537353691L);

        SubCorridor subCorridorTwo =new SubCorridor(subCorridorProcessor);
        AirCondition floorOneSubCorridorTwoAc =new AirCondition();
        Light floorOneSubCorridorTwoLight=new Light();
        subCorridorTwo.setAirCondition(floorOneSubCorridorTwoAc);
        subCorridorTwo.setLight(floorOneSubCorridorTwoLight);
        subCorridorTwo.setSubCorridorNumber(2);
//        subCorridorTwo.setLastProcessedTime(Instant.now().toEpochMilli());
        subCorridorTwo.setLastProcessedTime(1551537353691L);

        subCorridors.add(subCorridorOne);
        subCorridors.add(subCorridorTwo);

        return new Floor(mainCorridors, subCorridors,floorProcessor);

    }

}

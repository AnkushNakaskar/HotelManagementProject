package com.sahaj.hotel;

import com.sahaj.hotel.bean.*;
import com.sahaj.hotel.constant.DeviceStatus;
import com.sahaj.hotel.manager.HotelManager;
import com.sahaj.hotel.manager.impl.HotelManagerImpl;
import com.sahaj.hotel.processor.CorridorProcessor;
import com.sahaj.hotel.processor.Processor;
import com.sahaj.hotel.processor.impl.FloorProcessor;
import com.sahaj.hotel.processor.impl.MainCorridorProcessor;
import com.sahaj.hotel.processor.impl.SubCorridorProcessor;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

public class HotelApplicationTest {

    private HotelManager hotelManager;

    private static LocalDateTime sixPmTime = LocalDate.now().atTime(18, 00, 00);
    private static LocalDateTime sixAmTime = LocalDate.now().plusDays(1).atTime(6, 00, 00);
    private static LocalDateTime now = LocalDateTime.now();

    @Before
    public void setup(){
        hotelManager=new HotelManagerImpl();
    }




    @Test
    public void testNoMovement(){
        Hotel hotel = new Hotel();
        List<Floor> floors = new LinkedList<>();
        Floor floorOne = populateFloor();
        floorOne.getMainCorridors().get(0).setLastProcessedTime(Instant.now().minusSeconds(120).toEpochMilli());
        floorOne.getSubCorridors().get(0).setLastProcessedTime(Instant.now().minusSeconds(120).toEpochMilli());
        floorOne.getSubCorridors().get(1).setLastProcessedTime(Instant.now().minusSeconds(120).toEpochMilli());
        floors.add(floorOne);
        hotel.setFloors(floors);
        System.out.println(Instant.now().toEpochMilli());
        hotelManager.manage(hotel);

        if (now.isAfter(sixPmTime) && now.isBefore(sixAmTime)) {
            Assert.assertEquals(DeviceStatus.OFF,floorOne.getMainCorridors().get(0).getLight().getDeviceStatus());
            Assert.assertEquals(DeviceStatus.OFF,floorOne.getSubCorridors().get(1).getLight().getDeviceStatus());
            Assert.assertEquals(DeviceStatus.OFF,floorOne.getSubCorridors().get(0).getLight().getDeviceStatus());
        }

    }
    @Test
    public void testMovementAndNoMovementFromLast2Min() throws InterruptedException {
        Hotel hotel = new Hotel();
        List<Floor> floors = new LinkedList<>();
        Floor floorOne = populateFloor();
        floorOne.getMainCorridors().get(0).setLastProcessedTime(Instant.now().toEpochMilli());
        floorOne.getSubCorridors().get(0).setLastProcessedTime(Instant.now().minusSeconds(120).toEpochMilli());
        floors.add(floorOne);
        hotel.setFloors(floors);
        System.out.println(Instant.now());
        hotelManager.manage(hotel);

        System.out.println(floorOne);


        if (now.isAfter(sixPmTime) && now.isBefore(sixAmTime)) {
            Assert.assertEquals(DeviceStatus.ON,floorOne.getMainCorridors().get(0).getLight().getDeviceStatus());
            Assert.assertEquals(DeviceStatus.ON,floorOne.getSubCorridors().get(1).getLight().getDeviceStatus());
            Thread.sleep(4*60*1000);
            Assert.assertEquals(DeviceStatus.OFF,floorOne.getMainCorridors().get(0).getLight().getDeviceStatus());
            Assert.assertEquals(DeviceStatus.OFF,floorOne.getSubCorridors().get(1).getLight().getDeviceStatus());
        }else {
            Assert.assertEquals(DeviceStatus.OFF,floorOne.getMainCorridors().get(0).getLight().getDeviceStatus());
            Assert.assertEquals(DeviceStatus.OFF,floorOne.getSubCorridors().get(1).getLight().getDeviceStatus());
        }
        Assert.assertEquals(DeviceStatus.ON,floorOne.getMainCorridors().get(0).getAirCondition().getDeviceStatus());
        Assert.assertEquals(DeviceStatus.ON,floorOne.getSubCorridors().get(1).getAirCondition().getDeviceStatus());
    }



    public static Floor populateFloor(){
        CorridorProcessor<SubCorridor> subCorridorProcessor = new SubCorridorProcessor();
        CorridorProcessor<Corridor> corridorProcessor = new MainCorridorProcessor();
        Processor<Floor> floorProcessor = new FloorProcessor();

        List<Corridor> mainCorridors = new LinkedList<>();
        Corridor corridor =new Corridor(corridorProcessor);
        AirCondition floorOneCorridorAc =new AirCondition();
        Light floorOneCorridorLight=new Light();
        corridor.setAirCondition(floorOneCorridorAc);
        corridor.setLight(floorOneCorridorLight);
        corridor.setCorridorNumber(1);
        corridor.setLastProcessedTime(Instant.now().toEpochMilli());
        mainCorridors.add(corridor);

        List<SubCorridor> subCorridors = new LinkedList<>();

        SubCorridor subCorridorOne =new SubCorridor(subCorridorProcessor);
        AirCondition floorOneSubCorridorOneAc =new AirCondition();
        Light floorOneSubCorridorOneLight=new Light();
        subCorridorOne.setAirCondition(floorOneSubCorridorOneAc);
        subCorridorOne.setLight(floorOneSubCorridorOneLight);
        subCorridorOne.setSubCorridorNumber(1);
        subCorridorOne.setLastProcessedTime(Instant.now().toEpochMilli());

        SubCorridor subCorridorTwo =new SubCorridor(subCorridorProcessor);
        AirCondition floorOneSubCorridorTwoAc =new AirCondition();
        Light floorOneSubCorridorTwoLight=new Light();
        subCorridorTwo.setAirCondition(floorOneSubCorridorTwoAc);
        subCorridorTwo.setLight(floorOneSubCorridorTwoLight);
        subCorridorTwo.setSubCorridorNumber(2);
        subCorridorTwo.setLastProcessedTime(Instant.now().toEpochMilli());

        subCorridors.add(subCorridorOne);
        subCorridors.add(subCorridorTwo);

        return new Floor(mainCorridors, subCorridors,floorProcessor);

    }
}

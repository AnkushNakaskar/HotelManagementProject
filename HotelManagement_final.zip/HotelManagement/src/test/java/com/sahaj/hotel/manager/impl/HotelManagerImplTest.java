package com.sahaj.hotel.manager.impl;

import com.sahaj.hotel.bean.Corridor;
import com.sahaj.hotel.bean.Floor;
import com.sahaj.hotel.bean.Hotel;
import com.sahaj.hotel.bean.SubCorridor;
import com.sahaj.hotel.manager.HotelManager;
import com.sahaj.hotel.processor.CorridorProcessor;
import com.sahaj.hotel.processor.Processor;
import com.sahaj.hotel.processor.impl.FloorProcessor;
import com.sahaj.hotel.processor.impl.MainCorridorProcessor;
import com.sahaj.hotel.processor.impl.SubCorridorProcessor;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.LinkedList;
import java.util.List;

public class HotelManagerImplTest {


    @InjectMocks
    private HotelManagerImpl manager;

    @Mock
    private Processor<Floor> floorProcessor;


    @Before
    public void setup(){
        MockitoAnnotations.initMocks(this);
        manager=new HotelManagerImpl();
    }

    @Test
    public void testNoFloorHotel(){
        Hotel hotel =new Hotel();
        manager.manage(hotel);
        Mockito.verify(floorProcessor,Mockito.times(0)).process(Mockito.any());
    }

    @Test
    public void testFloorHotel(){
        Hotel hotel =new Hotel();
        List<Floor> floors =new LinkedList<>();
        Floor floor =Mockito.mock(Floor.class);
        floors.add(floor);
        hotel.setFloors(floors);
        manager.manage(hotel);
        Mockito.verify(floor,Mockito.times(1)).process();
    }
}

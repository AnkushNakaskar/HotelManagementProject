package com.sahaj.hotel.processor.impl;

import com.sahaj.hotel.HotelApplicationTestUtil;
import com.sahaj.hotel.bean.Consumption;
import com.sahaj.hotel.bean.Floor;
import com.sahaj.hotel.bean.SubCorridor;
import com.sahaj.hotel.constant.DeviceStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;

public class SubCorridorProcessorTest {

    @InjectMocks
    private SubCorridorProcessor subCorridorProcessor;

    private static final Integer allowMotionLimit = 2;

    private static LocalDateTime sixPmTime = LocalDate.now().atTime(18, 00, 00);
    private static LocalDateTime sixAmTime = LocalDate.now().atTime(6, 00, 00);
    private static LocalDateTime now = LocalDateTime.now();


    @Before
    public void setup(){
        subCorridorProcessor=new SubCorridorProcessor();
    }

    @Test
    public void testLight(){
        Floor floor=HotelApplicationTestUtil.populateFloor();
        SubCorridor subCorridor = floor.getSubCorridors().get(0);
        subCorridorProcessor.processingLight(subCorridor,floor);
        if (now.isAfter(sixPmTime) && now.isBefore(sixAmTime)) {
            Assert.assertEquals(DeviceStatus.ON,subCorridor.getLight().getDeviceStatus());
        }else{
            Assert.assertEquals(DeviceStatus.OFF,subCorridor.getLight().getDeviceStatus());
        }

    }

    @Test
    public void testAirCondition(){
        Floor floor=HotelApplicationTestUtil.populateFloor();
        SubCorridor subCorridor = floor.getSubCorridors().get(0);
        subCorridorProcessor.processingAirCondition(subCorridor,floor);
        Assert.assertEquals(DeviceStatus.ON,subCorridor.getAirCondition().getDeviceStatus());
    }

    @Test
    public void testCrossConsumptionLimitAirCondition(){
        Floor floor=HotelApplicationTestUtil.populateFloor();
        floor.setTotalconsumption(new Consumption(50));
        SubCorridor subCorridor = floor.getSubCorridors().get(0);
        subCorridorProcessor.processingLight(subCorridor,floor);
        subCorridorProcessor.processingAirCondition(subCorridor,floor);
        Assert.assertEquals(DeviceStatus.ON,subCorridor.getAirCondition().getDeviceStatus());
        Assert.assertEquals(DeviceStatus.OFF,floor.getSubCorridors().get(1).getAirCondition().getDeviceStatus());
    }

}
